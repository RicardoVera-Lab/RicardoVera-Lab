# SURVIVING CONTRIBUTION AFTER CLOSURE-02

## 1. What survives Gate A

The strongest surviving H6 object is **not** “a classification of projective `[16,7]` codes.” That ambient classification predates H6.

The surviving candidate is the compound statement:

> Among affine-spanning 16-point subsets of `AG(6,2)` — equivalently, projective binary `[16,7]` codes containing the all-one word — exactly 71 affine/code-equivalence classes have dual dependency code free of a 3-dimensional one-weight `[14,3,8]` subcode; and every admissible one-point extension of those extremal classes destroys that forbidden-free property.

This combines four features:

1. a specific all-one/self-complementary projective subfamily;
2. a specific dual forbidden-subcode predicate;
3. an extremal census (`71`);
4. a zero-extension boundary/certificate (`71×48=3408` internal extension checks).

The prior-art attack found strong overlap at item 1's ambient universe, but did not locate items 2–4 as a published combined result.

### Status

**Potentially original, not originality-certified.**  
Gate label: `B_PARTIAL_OVERLAP`.

The result should not be presented publicly as “71 new codes.” A publication-facing framing, if later supported, should focus on a **forbidden-subconfiguration extremal classification in affine binary geometry / dependency codes**.

---

## 2. What survives Gate B

Threshold-17 remains:

> Every affine-spanning 17-point set in `AG(6,2)` has a duplicated-simplex `[14,3,8]` dependency.

Alderson supplies a powerful 16-point direction theorem but not the simultaneous disjoint realization required by the duplicated simplex.

### Status

**`A_COMPUTER_ONLY`**.

This means:
- internally supported by exhaustive computation/certification;
- not located as an exact prior theorem;
- not derived conceptually from Alderson;
- not rejected.

---

## 3. Most valuable new mathematical target

The next target should be the isolated human lemma:

### 17-point Extension Rainbow-Matching Lemma

For every affine-spanning `S⊂F_2^6`, `|S|=17`, there exists a 3-space `V≤F_2^6` such that the seven matchings

`M_a(S) = {{x,x+a}:x,x+a∈S}`,  `a∈V\{0}`,

have pairwise vertex-disjoint representatives.

A proof of this lemma would convert Threshold-17 from `A_COMPUTER_ONLY` to an internal `A_NEW_PROOF_CANDIDATE` unless prior-art search then finds the same theorem.

The 71 extremal 16-point classes are not just output; they are the best laboratory for discovering the proof. Each class represents a maximal obstruction before the seventeenth point is added. The right strategy is to classify the obstruction types and prove that every legal extension destroys them.

---

## 4. Publication posture

Until the representative-level historic comparison and independent certificate hardening are complete, the strongest safe wording is:

> “We obtained an independently computed 71-class extremal census and zero-extension certificate for a forbidden duplicated-simplex configuration in spanning subsets of `AG(6,2)`. The ambient projective `[16,7]` code universe was enumerated previously; an exact prior-art equivalence for this filtered census has not been established. The associated 17-point threshold is currently computer-assisted, and Alderson's 2026 direction theorem does not by itself provide the required disjoint matching.”

No “first”, “new theorem”, or “novel classification” language should be used yet.
