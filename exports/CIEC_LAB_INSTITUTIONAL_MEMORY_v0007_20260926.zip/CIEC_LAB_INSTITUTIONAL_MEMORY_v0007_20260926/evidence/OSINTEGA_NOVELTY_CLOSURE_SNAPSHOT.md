# OSINTEGA Ω — H6-NOVELTY-CLOSURE-02

MISSION_ID: H6-NOVELTY-CLOSURE-02  
MODE: TARGETED PRIOR-ART / DATABASE RECOVERY / MATHEMATICAL EQUIVALENCE ATTACK  
CONSEQUENCE_PROFILE: MISSION_CRITICAL  
DATE: 2026-09-25  
OWNER: FORGE Ω  

## Executive verdict

This closure mission did **not** repeat the broad H6 novelty audit. It attacked only the two previously open gates.

### GATE A — PROJECTIVE_[16,7]_DATABASE_GATE

**AUTHORIZED STATUS: `B_PARTIAL_OVERLAP`**  
**Confidence: HIGH** that the ambient projective `[16,7]` classification was already enumerated at count level; **MODERATE** that no public source located in this audit already states the exact forbidden-subcode-filtered `71` census.

Decisive finding: the Bayreuth/FRIB table `S_{nk2}` explicitly lists **745,413** isometry classes of projective binary `[16,7]` codes at `n=16,k=7`, with the page dated 10 May 2016. Thus the ambient code universe is unquestionably prior art.

The exact mathematical bridge was reconstructed:

`spanning 16-set S⊂AG(6,2)`  
`↔ projective binary [16,7] code D_S containing 1^16`  
`↔ even dual [16,9,≥4] dependency code C_S=D_S^⊥`.

Moreover, affine equivalence of the point sets is exactly coordinate-permutation equivalence of the corresponding projective `[16,7]` codes **within the all-one subfamily**.

However, the mission did **not** recover an external representative file for all `745,413` classes, nor a public all-one subcatalog, nor an external computation showing that the additional filter

> `C_S` contains no 3-dimensional one-weight `[14,3,8]` subcode

returns exactly `71` equivalence classes. The Langevin page documents a `proj-k-n.txt` representative-file convention and an `all files` directory, but the directory is currently HTTP 403 and no indexed `proj-7-16.txt` mirror was recovered. Standard Magma and Sage code-database interfaces located in this audit are best-known-code resources, not exhaustive `[16,7]` class catalogs.

**Closure interpretation:** the phrase “71 previously unknown projective `[16,7]` codes” is not defensible. The potentially original object, if it survives independent comparison, is narrower: the **specific all-one / dual-forbidden-subcode filtered census, its 71-class boundary, and the zero-extension obstruction/certificate**.

### GATE B — ALDERSON_BRIDGE_GATE

**AUTHORIZED STATUS: `A_COMPUTER_ONLY`**  
**Subfinding: the naive implication `Alderson solid ⇒ duplicated-simplex matching` is not established and is not contained in Alderson's proof.**  
**Confidence: HIGH** on what Alderson proves; **MODERATE-HIGH** that the standard rainbow-matching results located do not supply the missing bridge.

Alderson's Theorem 5.1 states exactly:

> Every 16-point set `T⊂AG(6,2)` has a direction set `D(T)` containing a solid `PG(3,2)` in `PG(5,2)`.

His proof establishes **direction coverage**. In the final lifting step, for each of seven points `R` of a plane in a quotient, it chooses witnesses producing two direction points above `R`; the construction does not require the underlying point-pairs in `T` to be pairwise vertex-disjoint across different `R`.

For a point set `S`, define for every nonzero direction `a`:

`M_a(S) = { {x,x+a} : x,x+a∈S }`.

Each `M_a(S)` is itself a matching. Threshold-17 requires a 3-space `V≤F_2^6` and a **rainbow matching of size 7** selecting one edge from every `M_a(S)`, `a∈V\{0}`, so that 14 distinct endpoints realize the duplicated simplex. Alderson guarantees only that, for some 4-space `U`, every `M_a(T)` with `a∈U\{0}` is nonempty.

Generic rainbow-matching theorems found in the targeted attack require stronger density/degree or color-class-size hypotheses than Alderson supplies. None located turns mere nonemptiness of seven (or fifteen) direction color classes on 16/17 vertices into the required 7-edge disjoint transversal.

Therefore Threshold-17 remains, under the evidence presently available, a **computer-assisted-only H6 result**, not a known corollary of Alderson and not yet an internally proved conceptual theorem.

## Required final questions

### Does the 71-class frontier / zero-extension certificate still represent a potentially original mathematical contribution?

**YES — but only in a narrowed sense.** The ambient `[16,7]` projective classification is prior art. What still survives as a potentially original contribution is the exact **filtered affine/code classification** (all-one + duplicated-simplex-free dual), the count `71`, the extension frontier, and the `71×48=3408` zero-extension certificate, provided that a direct representative-level comparison against historical catalogs does not reproduce the same filtered census.

This is **not** a novelty certification. The current defensible status is `B_PARTIAL_OVERLAP`.

### Threshold-17 status?

**`A_COMPUTER_ONLY`.**  
Not `A_KNOWN_COROLLARY`; no published bridge was found.  
Not `A_NEW_PROOF_CANDIDATE`; this mission isolated the missing lemma but did not prove it.  
Not `A_REJECTED`; no counterexample to the internal threshold was found.

## Strongest next move

Do **not** spend another broad search cycle. Move to a certificate/comparison gate:

1. freeze the 71 internal representatives in a machine-readable format;
2. compute canonical forms, automorphism orders and stable hashes;
3. recover or independently regenerate the `745,413` projective `[16,7]` class universe;
4. select the all-one subfamily and apply the exact duplicated-simplex filter;
5. compare the resulting canonical set with the internal 71;
6. separately attack the isolated 17-point rainbow-matching lemma with the 71 extremal 16-point classes as obstruction data.
