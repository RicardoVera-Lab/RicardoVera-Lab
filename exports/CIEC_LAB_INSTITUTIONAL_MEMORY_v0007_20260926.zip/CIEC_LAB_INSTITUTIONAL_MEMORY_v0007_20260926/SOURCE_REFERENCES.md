# Source References

## Institutional base
- `CIEC_LAB_INSTITUTIONAL_MEMORY_v0006_20260925.zip`
- Library file id: `file_00000000ad3c820eb22716d3d5bf05a5`

## H6 hardening
- `ALETHEIA_H6_LOWER25_PUBLICATION_HARDENING_01_20260925.zip`
- `CIEC_LAB_H6_QUADRATIC_IMAGE_THEOREM_GITHUB_SOURCE_20260926.zip`

## Novelty
- `OSINTEGA_H6_NOVELTY_PRIORITY_AUDIT_01_2026-09-25.zip`
- `OSINTEGA_H6_NOVELTY_CLOSURE_02_2026-09-25.zip`

## Public GitHub
- https://github.com/RicardoVera-Lab/h6-universal-quadratic-image-theorem
- https://github.com/RicardoVera-Lab/cs06-hypnosis-mechanism-identification-case-study
- https://github.com/RicardoVera-Lab/cs05-topological-overshoot-case-study
- https://github.com/RicardoVera-Lab/RicardoVera-Lab
