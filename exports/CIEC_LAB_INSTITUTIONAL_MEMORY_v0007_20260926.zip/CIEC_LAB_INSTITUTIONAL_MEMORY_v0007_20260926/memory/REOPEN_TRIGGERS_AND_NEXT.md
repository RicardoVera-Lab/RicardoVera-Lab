# Reopen Triggers and Next Authorized Moves

## H6 lower25 reopen triggers

Reopen the frozen `h(6)>=25` proof only if one of the following appears:
- a valid target counterexample with <=24 points;
- a broken evaluation-equivalence bridge;
- a missing dangerous 2D profile;
- an invalid exact-kernel witness;
- a Delsarte certificate failing strict `>640`;
- a missing hypothesis in the external sum-free theorem;
- a feasible safe-weight dimension-10 code;
- an unclosed all-one branch;
- a formal/independent reconstruction that identifies a real contradiction.

Novelty-only evidence does not by itself falsify the theorem.

## 71-class side result reopen trigger

Reopen priority comparison when:
- historical `proj-7-16` representatives are recovered; or
- the full all-one projective `[16,7]` subfamily is independently regenerated and the exact forbidden-subcode filter is compared representative-by-representative.

## C7 strengthening reopen trigger

Only continue from **verified artifacts**. Do not use unsupported conversational continuation states.

## Next authorized research program

**H-GENERAL — ADAPTIVE DEPENDENCY MATCHING**

Goal:
Determine whether the H6 22→24 mechanism generalizes beyond (n=6).

Order:
1. symbolic decomposition of the H6 proof into (n)-general vs (n=6)-specific steps;
2. small-(n) exact census;
3. identify invariant/pattern;
4. freeze the weakest meaningful conjecture;
5. only then authorize heavy computation.

Prohibition:
Do not begin by brute-forcing (n=7) as a blind clone of H6.
