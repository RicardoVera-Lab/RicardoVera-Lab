# Capability Evidence Delta

## CAP-H6-MATHEMATICAL-DISCOVERY

**Lifecycle:** `VALIDATED_IN_SCOPE`  
**Do not promote to:** `OPERATIONALLY_PROVEN` from one research case.

Evidence:
- open technical problem was reformulated into standard mathematical languages;
- a positive lower bound `h(6)>=25` was frozen;
- proof bridges were reconstructed and adversarially attacked;
- finite obligations were reduced to exact certificates;
- no unresolved internal bridge remained within frozen scope.

Allowed use:
- evidence that CIEC LAB can produce and harden a computer-assisted mathematical result in this scope.

Prohibited use:
- claim that CIEC LAB can solve arbitrary open mathematics;
- claim that one case establishes general mathematical research performance.

---

## CAP-H6-PROOF-HARDENING

**Lifecycle:** `VALIDATED_IN_SCOPE`

Evidence:
- 46 dangerous 2D profiles;
- 45 exact-kernel witness profiles;
- unique exceptional profile `(12,12,24)`;
- 9 exact rational Delsarte certificate checks, all strict `>640`;
- zero MacWilliams survivors in the safe-weight closure;
- all-one exceptional branch closed;
- primary and second internal implementations reported PASS.

Limit:
- both internal implementations share witness data and Delsarte certificate coefficients.

---

## CAP-H6-PRIOR-ART-EQUIVALENCE-ATTACK

**Lifecycle:** `TESTED / VALIDATED_IN_SCOPE`

Evidence:
- novelty search translated the private `h(6)` notation into quadratic-map, vectorial Boolean, Reed-Muller and interpolation language;
- no equivalent of the frozen `h(6)>=25` result was located in targeted search;
- broader prior art was correctly separated from the narrower 71-class filtered census;
- Alderson's direction theorem was separated from the missing disjoint/rainbow-matching bridge.

Limit:
- targeted search is not exhaustive historical priority certification.

---

## CAP-PUBLIC-REPRODUCIBILITY-PACKAGING

**Lifecycle:** `VALIDATED_IN_SCOPE`

Evidence:
- theorem repo published;
- public clean-room verifier included;
- witness corpus included;
- GitHub Actions exact verification completed successfully.

---

## CAP-HIGH-CONSEQUENCE-CONSULTING-POSITIONING

**Lifecycle:** `DEFINED / PUBLICLY_TESTED AS MESSAGING`

Evidence:
- portfolio reframed around three demonstrated case capabilities:
  - H6 = DISCOVER;
  - CS06 = CHALLENGE / DECISION INTELLIGENCE;
  - CS05 = VERIFY / EVIDENCE INTEGRITY.

Do not treat as:
- paid demand;
- product-market fit;
- proven high-ticket conversion.
