# Asset Registry Delta

## ASSET-H6-PUBLIC-REPOSITORY
**State:** `VERIFIED_ASSET / PUBLIC_SAFE`  
URL: https://github.com/RicardoVera-Lab/h6-universal-quadratic-image-theorem  
Use: proof-facing public artifact, portfolio evidence, reproducibility reference.

## ASSET-H6-CERTIFICATE-CAPSULE
**State:** `VERIFIED_ASSET / REUSABLE`  
Includes theorem statement, proof architecture, exact witnesses, certificate checks, adversarial attacks and residual-risk boundary.

## ASSET-H6-PUBLIC-VERIFIER
**State:** `VERIFIED_ASSET / REUSABLE`  
Primary verifier SHA-256:
`03b080ea2b24fda30e27a08b5fd1c52d859cb4a113342ddaa84ce3803557cc9f`

Witness corpus SHA-256:
`75151f69a7325673c3270fa0aab35a222bb0263f6ab7ae26b953bf45d10c5eac`

## ASSET-ADAPTIVE-DEPENDENCY-MATCHING
**State:** `NOMINATED`  
Type: conceptual research mechanism / next-program seed.  
Do not promote to a general theorem until cross-n evidence exists.

## ASSET-H6-71-FRONTIER
**State:** `NOMINATED`  
Current boundary: potentially original filtered extremal census, but ambient projective [16,7] universe is prior art.  
Do not market as "71 new codes."

## ASSET-CIEC-PORTFOLIO-TRIAD
**State:** `REUSABLE / PUBLIC_SAFE`

Narrative:
- **DISCOVER** — H6 mathematical discovery.
- **CHALLENGE** — CS06 decision intelligence.
- **VERIFY** — CS05 evidence integrity.

## ASSET-CIEC-PROFILE-POSITIONING
**State:** `REUSABLE / PUBLIC_SAFE`

Positioning:
**CIEC LAB · Strategic Research · Decision Intelligence · High-Consequence R&D**

Tagline:
**We attack uncertainty before it becomes capital loss.**

Commercial line:
**The deliverable is not more analysis. The deliverable is a decision you can defend.**
