# Research Seed — H-GENERAL

## Core question

For degree-<=2 Boolean evaluation,

[
D_n=1+n+\binom n2.
]

H6 shows at (n=6):

[
D_6=22
]

while universal target containment reaches at least 24.

Research question:

> Is the excess beyond the raw evaluation dimension an isolated (n=6) phenomenon, or does adaptive dependency matching produce a general family of lower bounds?

## Candidate hypothesis families

Do **not** assume any of these:
- (h(n)\ge D_n+3);
- fixed (+2) excess for all (n);
- monotone excess;
- asymptotic excess.

Treat them as competing hypotheses.

## First mission

Map every proof step into:
- GENERAL_IN_n;
- N6_SPECIFIC;
- DEPENDS_ON_EXTERNAL_THEOREM;
- FINITE_ENUMERATION_ARTIFACT;
- UNKNOWN_GENERALIZATION.

Only after that map exists should computation scale.
