# Public Portfolio State — 2026-09-26

## GitHub identity

Profile:
https://github.com/RicardoVera-Lab

Profile repository:
https://github.com/RicardoVera-Lab/RicardoVera-Lab

## Pinned research cases

### 1. H6 — Universal Quadratic Image Theorem
https://github.com/RicardoVera-Lab/h6-universal-quadratic-image-theorem

Role in portfolio:
**DISCOVER / Mathematical Discovery**

### 2. CS06 — Hypnosis Mechanism Identification
https://github.com/RicardoVera-Lab/cs06-hypnosis-mechanism-identification-case-study

Role:
**CHALLENGE / Decision Intelligence**

### 3. CS05 — Topological Overshoot
https://github.com/RicardoVera-Lab/cs05-topological-overshoot-case-study

Role:
**VERIFY / Evidence Integrity**

## Portfolio narrative

**DISCOVER -> CHALLENGE -> VERIFY**

The profile README translates the three cases into a boutique high-consequence consulting proposition while preserving case-specific scientific boundaries.
