# Claim Boundary

## Authorized public statements

- H6 is a CIEC LAB **computer-assisted mathematical theorem/result**.
- The frozen statement establishes `h(6)>=25`.
- Any set of at most 24 distinct targets in (mathbb F_2^{12}) is contained in the image of some coordinatewise quadratic map from (mathbb F_2^6).
- A targeted prior-art search found no equivalent of the main frozen result.
- The public verifier and witness corpus are available on GitHub.
- The public GitHub verification workflow passed.

## Statements that require qualification

- "new theorem": acceptable as CIEC LAB discovery framing only when accompanied by the prior-art boundary; do not convert it into exhaustive historical priority.
- "independent verification": specify **internal second implementation** unless a true third party reproduces it.

## Unauthorized / unsupported statements

- "first in history";
- `h(6)=25`;
- `h(6)>=26`;
- "the 71 classes are 71 new projective codes";
- "Threshold-17 has a human conceptual proof";
- "adaptive dependency matching is a theorem for all (n)";
- "H6 already improves a real-world technology";
- "the portfolio proves paid high-ticket market demand."
