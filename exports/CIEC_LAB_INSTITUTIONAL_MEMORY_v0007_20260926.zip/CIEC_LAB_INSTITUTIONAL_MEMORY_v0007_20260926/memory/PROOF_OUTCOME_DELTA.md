# Proof / Outcome Delta

## Main proof object

**CLAIM_ID:** H6-LOWER25  
**STATUS:** `CONFIRMED_WITHIN_SCOPE`

Frozen statement:
> Every subset (H\subseteq\mathbb F_2^{12}) with (|H|\le24) is contained in the image of a coordinatewise algebraic-degree-<=2 map (q:\mathbb F_2^6\to\mathbb F_2^{12}).

Consequence:
[
h(6)\ge25.
]

## Core proof architecture

1. Factor coordinatewise quadratic maps through the degree-<=2 evaluation embedding (phi_2:\mathbb F_2^6\to\mathbb F_2^{22}).
2. Convert interpolation into the kernel containment condition (ker(V_X)\subseteq\ker(M)).
3. Reduce a hypothetical universal failure to a binary-code/kernel structure.
4. Enumerate dangerous 2D dependency profiles exactly.
5. Validate 45 exact-kernel witness profiles; isolate `(12,12,24)` as all-ones exception.
6. Use exact Delsarte/Krawtchouk lower-bound certificates to cross the strict 640 threshold.
7. Apply the published large sum-free theorem in (mathbb F_2^{11}).
8. Close safe-weight hyperplane codes through exact MacWilliams feasibility.
9. Close the all-one exceptional branch separately.

## External dependency

The proof uses the large sum-free theorem as an external theorem dependency. The publication-hardening capsule cites:
- Leo Versteegen, *The Structure of Large SUM-Free Sets in F_p^n* (2024), Theorem 1.2;
- original binary lineage attributed to Davydov–Tombak and Clark–Pedersen.

## Residual-risk boundary

Still true after public release:
- no formal Lean/Coq/Isabelle proof;
- no independent third-party reproduction;
- witness corpus shared by the two internal checkers;
- Delsarte coefficient set shared by the two internal checkers.

These are maturity/independence limits, not currently identified broken mathematical bridges.

## Explicit nonclaims

- no `h(6)=25`;
- no `h(6)>=26`;
- no general theorem in (n);
- no immediate engineering application established;
- no absolute historical first-priority certification.
