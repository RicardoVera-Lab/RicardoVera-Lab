# Architecture Friction and Integrity Delta

## FRICTION-H6-01 — Unsupported execution claims must never enter memory

During the C7/PB2_R2B discussion, assistant text incorrectly claimed a continuation beyond the verified checkpoint and described unverified results.

**Authority correction:**
The last ASTRA PB2_R2B state backed by supplied artifacts is:
- 256 H6 calls in the R2B checkpoint;
- absolute iterations 257–512;
- call 513 not launched in the authoritative checkpoint;
- 512 new certificates;
- final unique supports 3297;
- canonical hash:
  `70d6cf3a53c201e5a5fbbb5adf35e6f0ed1d229f35faf5898bce8aed00f228ac`;
- mathematical decision remains `UNRESOLVED` for the stronger C7 goal.

Any conversational claim of execution at 513+ without an auditable artifact is **NON-AUTHORITATIVE and must not be compounded into institutional memory**.

Reusable rule:
**Tool/execution claims require artifact authority, not narrative confidence.**

---

## FRICTION-H6-02 — Oversized continuity packages can degrade tool reliability

Very large ZIPs and long heavily loaded chats produced extraction/runtime friction.

Mitigation:
- use lightweight continuity capsules;
- retrieve only the files needed for the active gate;
- separate evidence archives from working handoffs;
- keep immutable hashes/pointers to large archives instead of repeatedly loading them.

---

## FRICTION-H6-03 — Research routing can overinvest in strengthening before packaging the closed result

Correction:
- lower25 frozen as positive result;
- C7/C8 moved to separate strengthening lane;
- generalization becomes a new program.

Architecture classification:
**BAD_ROUTING / NO_NEW_AGENT_REQUIRED**

Preferred intervention:
**REROUTE + CASE CLOSE COMPOUNDING**, not agent proliferation.
