# Novelty and Side-Result Delta

## Main result h(6)>=25

**Targeted-search status:** `NO_EQUIVALENT_FOUND_IN_SEARCH`  
**Correct public interpretation:** CIEC LAB mathematical discovery / computer-assisted theorem; no absolute first-in-history claim.

## 71-class frontier

Gate:
`PROJECTIVE_[16,7]_DATABASE_GATE = B_PARTIAL_OVERLAP`

Known prior art:
- the ambient projective binary `[16,7]` universe was already enumerated;
- Bayreuth/FRIB count: **745,413** isometry classes.

What may still be original:
- the exact all-one subfamily + dual forbidden `[14,3,8]` predicate;
- the filtered extremal census of **71** classes;
- the zero-extension boundary/certificate over **71×48 = 3408** extensions.

Forbidden marketing:
- "71 new projective [16,7] codes."

## Threshold-17

Gate:
`ALDERSON_BRIDGE_GATE = A_COMPUTER_ONLY`

Current statement:
Every affine-spanning 17-point subset of `AG(6,2)` contains the duplicated-simplex dependency.

Alderson 2026 gives direction-solid coverage for 16 points, but not the seven pairwise-disjoint witness pairs required for the duplicated simplex.

No located standard rainbow-matching theorem closes that gap from Alderson's hypotheses alone.

## Best human-proof target

**17-point Extension Rainbow-Matching Lemma**

Use the 71 extremal 16-point classes as a finite obstruction laboratory. This remains a separate side program and is not required for the frozen `h(6)>=25` portfolio result.
