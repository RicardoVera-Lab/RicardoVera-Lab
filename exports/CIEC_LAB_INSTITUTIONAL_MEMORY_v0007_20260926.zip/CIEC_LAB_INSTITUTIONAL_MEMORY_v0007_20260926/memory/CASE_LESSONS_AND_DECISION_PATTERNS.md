# Case Lessons and Decision Patterns

## DP-H6-01 — Extract a closed positive result before chasing a stronger frontier

Pattern:
A program can become trapped trying to determine the strongest possible bound while already possessing a meaningful closed lower result.

H6 lesson:
Once `h(6)>=25` survived hardening, exact closure of `h(6)` stopped being a prerequisite for portfolio value.

Reusable rule:
**Freeze the strongest closed positive result; separate strengthening into a new lane.**

---

## DP-H6-02 — Translate private notation into standard mathematical languages

The private parameter notation alone was a weak prior-art search key.

High-value translations:
- quadratic maps over (mathbb F_2);
- vectorial Boolean functions;
- `RM(2,6)` evaluation geometry;
- kernel containment;
- projective/affine code duality.

Reusable rule:
**Novelty search quality depends on equivalence translation, not keyword volume.**

---

## DP-H6-03 — Truth, novelty, importance, publicability and action are separate states

H6 repeatedly benefited from refusing to merge:
- mathematically established within scope;
- not found in prior art;
- important/general;
- safe to release;
- commercially useful.

Reusable rule:
**Never let one gate auto-promote another.**

---

## DP-H6-04 — Adaptive dependency matching is a research mechanism, not yet a general theorem

The 22→24 gain suggests a potentially general mechanism.

Reusable rule:
**Promote mechanisms as research seeds before promoting them as laws.**

---

## DP-H6-05 — Portfolio triangulation is stronger than three similar successes

The public portfolio now demonstrates:
- positive discovery;
- adversarial mechanism discrimination;
- evidence-integrity stopping discipline.

Reusable rule:
**Portfolio strength increases when cases prove different high-value capabilities rather than repeating the same type of result.**
