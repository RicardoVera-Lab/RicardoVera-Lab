# Base Version Reference

This v0007 package is an **overlay** on:

`CIEC_LAB_INSTITUTIONAL_MEMORY_v0006_20260925.zip`

Known Library copy:
- file id: `file_00000000ad3c820eb22716d3d5bf05a5`
- size: 900810 bytes
- created: 2026-09-25
- role at time of update: ACTIVE INSTITUTIONAL MEMORY

Do not discard v0006.  
Do not reinterpret this delta as a full reconstruction of all prior memory objects.

**Load order:** v0006 -> v0007.
